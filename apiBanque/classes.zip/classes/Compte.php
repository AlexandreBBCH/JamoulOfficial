<?php 

abstract class Compte
{
/**
 * Titulaire du compte
 * @var string
 */
protected $titulaire;

/**
 * Solde du compte
 * @var float
 */
protected $solde;
}
